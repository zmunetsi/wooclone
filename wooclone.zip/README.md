Woo Clone
=========

A perfect wordpress plugin for your next ecommerce project.

Set up and add products to your shop by form any API.

Getting started
---------------


### Setup on wordpress

[Getting Started on wordpress](https://en-za.wordpress.org/download/)

*   Download a zip file in this repo or clone and compress repo.
*   Install plugin/zip file downloaded on running wordpress site
*   Go to admin menu -> wooclone and setup endpoint settings

use the following endpoint fot testing:
https://my-json-server.typicode.com/zmunetsi/wooclone/products

The following pages will be created automatically during plugin installation:

*   products
*   cart
*   checkout
Create a new menu and add pages to access

### Attributes

The following packages where used in this project: [Primefaces React component](https://primefaces.org/)

### Contributions

Make sure you have node environment setup

*   Clone repo to local
*   npm install
*   npm run build to combile and build assets encued in plugin
*   Compress files to make it ready to install as wordpress plugin

Please submit a pull request to contribute to this package.


Hooray