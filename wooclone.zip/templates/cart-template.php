<?php
/**
 * The Wooclone products template
 *
 * Displays carousel of all products from API
 * @link munetsizunguzira.com
 *
 * @package Wooclone
 */

get_header();



?>

	<div id="primary" class="content-area">
		<main id="main" class="site-main">

            <section id = "new-swops" class="my-3">
                <div class="grid px-2 md:px-4 lg:px-8">
                <div id="cart-items" class="col-12"></div>
                </div>
            </section>


		</main><!-- .site-main -->
	</div><!-- .content-area -->

<?php
get_footer();
