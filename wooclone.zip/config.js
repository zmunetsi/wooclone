const api_endpoint = scriptParams.api_endpoint || 'https://my-json-server.typicode.com/zmunetsi/wooclone/products';
const site_url = scriptParams.site_url;
const is_user_logged_in = scriptParams.is_user_logged_in;
const is_user_admin = scriptParams.is_user_admin;
const user_name = scriptParams.logged_in_username;
const plugin_url = scriptParams.plugin_url;
const ajax_url = scriptParams.ajax_url;